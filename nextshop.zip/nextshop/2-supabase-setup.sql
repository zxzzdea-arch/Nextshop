-- =====================================================================
--  NEXTSHOP — ตั้งค่า Supabase (ก๊อปทั้งไฟล์ไปวางใน SQL Editor แล้วกด Run)
--  ⚠️ แก้อีเมลแอดมินที่บรรทัด "ADMIN EMAIL" ด้านล่างก่อนกด Run
--  ✔ รันซ้ำได้ปลอดภัย (ใช้อัปเดตจากเวอร์ชันเก่าได้ ข้อมูลเดิมไม่หาย)
-- =====================================================================

-- ---------- อีเมลที่จะเป็นแอดมิน (ไม่มีใครเป็นแอดมินอัตโนมัติ นอกจากอีเมลในตารางนี้) ----------
create table if not exists public.admin_emails (email text primary key);
alter table public.admin_emails enable row level security;  -- ไม่มี policy = ไม่มีใครอ่าน/แก้ผ่านเว็บได้

insert into public.admin_emails(email)
select lower(e) from (values ('ใส่อีเมลแอดมินของคุณ@gmail.com')) v(e)   -- <<< ADMIN EMAIL (แก้ตรงนี้)
where e not like 'ใส่%'
on conflict do nothing;

-- ---------- โปรไฟล์สมาชิก ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text, name text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.profiles add column if not exists last_ip text;
alter table public.profiles add column if not exists last_seen timestamptz;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false)
$$;

-- ---------- แบน IP / แบนบัญชี ----------
create table if not exists public.bans (
  id bigint generated always as identity primary key,
  kind text not null check (kind in ('ip','user')),
  value text not null, reason text, created_at timestamptz not null default now(),
  unique (kind, value)
);
alter table public.bans enable row level security;
drop policy if exists "bans admin" on public.bans;
create policy "bans admin" on public.bans for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- IP ของคนที่กำลังใช้เว็บ (Supabase ส่งมาใน header)
create or replace function public.client_ip() returns text
language sql stable as $$
  select nullif(trim(coalesce(
    nullif(current_setting('request.headers', true), '')::json->>'cf-connecting-ip',
    split_part(nullif(current_setting('request.headers', true), '')::json->>'x-forwarded-for', ',', 1)
  )), '')
$$;

-- ถูกแบนไหม (แอดมินไม่มีวันโดนแบน กันล็อกตัวเอง)
create or replace function public.is_banned() returns boolean
language sql stable security definer set search_path = public as $$
  select not public.is_admin() and exists (
    select 1 from public.bans b
    where (b.kind = 'ip' and b.value = public.client_ip())
       or (b.kind = 'user' and b.value = auth.uid()::text))
$$;

-- เรียกตอนเปิดเว็บ: บันทึก IP ล่าสุดของสมาชิก + บอกว่าโดนแบนไหม
create or replace function public.check_in() returns boolean
language plpgsql volatile security definer set search_path = public as $$
begin
  if auth.uid() is not null then
    update public.profiles set last_ip = public.client_ip(), last_seen = now() where id = auth.uid();
  end if;
  return public.is_banned();
end $$;

-- สร้างโปรไฟล์อัตโนมัติเมื่อมีคนสมัคร
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, email, name, is_admin)
  values (new.id, lower(new.email), coalesce(new.raw_user_meta_data->>'name', ''),
          exists(select 1 from public.admin_emails a where a.email = lower(new.email)))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ถ้าเพิ่มอีเมลแอดมินทีหลัง ให้บัญชีที่สมัครไว้แล้วเป็นแอดมินด้วย
create or replace function public.sync_admin_email() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set is_admin = true where email = lower(new.email);
  return new;
end $$;
drop trigger if exists on_admin_email_added on public.admin_emails;
create trigger on_admin_email_added after insert on public.admin_emails
  for each row execute function public.sync_admin_email();
update public.profiles p set is_admin = true from public.admin_emails a where p.email = a.email;

drop policy if exists "profile read" on public.profiles;
create policy "profile read" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
-- ไม่มี policy update/insert = สมาชิกตั้งตัวเองเป็นแอดมินไม่ได้

-- ---------- ตั้งค่าร้าน ----------
create table if not exists public.settings (k text primary key, v text);
alter table public.settings enable row level security;
drop policy if exists "settings read" on public.settings;
create policy "settings read" on public.settings for select to anon, authenticated using (true);
drop policy if exists "settings admin" on public.settings;
create policy "settings admin" on public.settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- สินค้า (ข้อมูลที่ทุกคนเห็น) ----------
create table if not exists public.products (
  id bigint generated always as identity primary key,
  title text not null, description text default '',
  price numeric(12,2) not null default 0 check (price >= 0),
  image_url text, active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;
drop policy if exists "products read" on public.products;
create policy "products read" on public.products for select to anon, authenticated
  using ((active and not public.is_banned()) or public.is_admin());
drop policy if exists "products admin" on public.products;
create policy "products admin" on public.products for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- คำสั่งซื้อ ----------
create table if not exists public.orders (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  product_id bigint not null references public.products(id) on delete restrict,
  amount numeric(12,2) not null default 0,
  slip_path text not null, note text default '',
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_note text, created_at timestamptz not null default now(), reviewed_at timestamptz
);
alter table public.orders enable row level security;
alter table public.orders add column if not exists ip text;
-- สถานะ: pending รอตรวจ / approved อนุมัติ / rejected ไม่อนุมัติ / revoked ยึดสิทธิ์คืน
alter table public.orders drop constraint if exists orders_status_check;
alter table public.orders add constraint orders_status_check
  check (status in ('pending','approved','rejected','revoked'));

-- กันโกง: ราคา / สถานะ / เจ้าของ ถูกกำหนดโดยระบบ ไม่ใช่จากหน้าเว็บ
create or replace function public.order_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if public.is_banned() then raise exception 'banned'; end if;
    new.user_id := auth.uid();
    new.ip := public.client_ip();
    new.status := 'pending'; new.admin_note := null; new.reviewed_at := null;
    select price into new.amount from public.products where id = new.product_id and active;
    if new.amount is null then raise exception 'product not available'; end if;
    if new.slip_path is null or split_part(new.slip_path, '/', 1) <> auth.uid()::text then
      raise exception 'invalid slip';
    end if;
  elsif tg_op = 'UPDATE' then
    new.user_id := old.user_id; new.product_id := old.product_id;
    new.amount := old.amount; new.slip_path := old.slip_path; new.ip := old.ip;
    if new.status is distinct from old.status then new.reviewed_at := now(); end if;
  end if;
  return new;
end $$;
drop trigger if exists order_guard on public.orders;
create trigger order_guard before insert or update on public.orders
  for each row execute function public.order_guard();

drop policy if exists "orders read" on public.orders;
create policy "orders read" on public.orders for select to authenticated
  using ((user_id = auth.uid() and not public.is_banned()) or public.is_admin());
drop policy if exists "orders insert" on public.orders;
create policy "orders insert" on public.orders for insert to authenticated
  with check (auth.uid() is not null and not public.is_banned());
drop policy if exists "orders admin update" on public.orders;
create policy "orders admin update" on public.orders for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
drop policy if exists "orders admin delete" on public.orders;
create policy "orders admin delete" on public.orders for delete to authenticated
  using (public.is_admin());

-- ---------- ลิงก์ลับ / ไฟล์ของสินค้า (เห็นเฉพาะแอดมิน + คนที่ได้รับอนุมัติแล้ว) ----------
create table if not exists public.product_secrets (
  product_id bigint primary key references public.products(id) on delete cascade,
  link text, file_path text, file_name text
);
alter table public.product_secrets enable row level security;

create or replace function public.has_bought(pid bigint) returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.orders
                where product_id = pid and user_id = auth.uid() and status = 'approved')
$$;

drop policy if exists "secrets read" on public.product_secrets;
create policy "secrets read" on public.product_secrets for select to authenticated
  using (public.is_admin() or (public.has_bought(product_id) and not public.is_banned()));
drop policy if exists "secrets admin" on public.product_secrets;
create policy "secrets admin" on public.product_secrets for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- สิทธิ์ตาราง (RLS ด้านบนเป็นตัวคุมจริง) ----------
grant usage on schema public to anon, authenticated;
grant select on public.products, public.settings to anon;
grant select, insert, update, delete on public.products, public.settings, public.orders,
  public.product_secrets to authenticated;
grant select on public.profiles to authenticated;
grant select, insert, update, delete on public.bans to authenticated;
grant execute on function public.is_admin(), public.has_bought(bigint), public.client_ip(),
  public.is_banned(), public.check_in() to anon, authenticated;

-- ---------- ที่เก็บไฟล์ ----------
--  media  = รูปสินค้า / QR (เปิดดูได้ทุกคน)
--  slips  = สลิป (เจ้าของ + แอดมินเท่านั้น)
--  files  = ไฟล์ขาย (แอดมิน + คนที่ได้รับอนุมัติเท่านั้น)
insert into storage.buckets (id, name, public, file_size_limit)
values ('media', 'media', true, 10485760),
       ('slips', 'slips', false, 10485760),
       ('files', 'files', false, null)
on conflict (id) do nothing;

drop policy if exists "media read" on storage.objects;
create policy "media read" on storage.objects for select to anon, authenticated
  using (bucket_id = 'media');
drop policy if exists "media admin write" on storage.objects;
create policy "media admin write" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and public.is_admin());
drop policy if exists "media admin update" on storage.objects;
create policy "media admin update" on storage.objects for update to authenticated
  using (bucket_id = 'media' and public.is_admin());
drop policy if exists "media admin delete" on storage.objects;
create policy "media admin delete" on storage.objects for delete to authenticated
  using (bucket_id = 'media' and public.is_admin());

drop policy if exists "slips upload own" on storage.objects;
create policy "slips upload own" on storage.objects for insert to authenticated
  with check (bucket_id = 'slips' and (storage.foldername(name))[1] = auth.uid()::text and not public.is_banned());
drop policy if exists "slips read" on storage.objects;
create policy "slips read" on storage.objects for select to authenticated
  using (bucket_id = 'slips' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

drop policy if exists "files admin" on storage.objects;
create policy "files admin" on storage.objects for all to authenticated
  using (bucket_id = 'files' and public.is_admin())
  with check (bucket_id = 'files' and public.is_admin());
drop policy if exists "files buyer read" on storage.objects;
create policy "files buyer read" on storage.objects for select to authenticated
  using (bucket_id = 'files' and exists (
    select 1 from public.product_secrets s
    where s.file_path = storage.objects.name and public.has_bought(s.product_id)) and not public.is_banned());

insert into public.settings(k, v) values ('shop_name', 'NEXTSHOP') on conflict (k) do nothing;

-- เสร็จแล้ว ✅
