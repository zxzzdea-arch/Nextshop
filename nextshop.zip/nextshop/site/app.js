// NEXTSHOP — หน้าเว็บ (GitHub Pages) + Supabase
// ความปลอดภัยจริงอยู่ที่ฐานข้อมูล (Row Level Security) — โค้ดหน้าเว็บนี้ถึงถูกแกะก็ไม่เห็นลิงก์ลับ
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

const cfg = window.SHOP_CONFIG || {};
const configured = /^https:\/\/.+\.supabase\.co\/?$/.test(cfg.SUPABASE_URL || "") &&
  !String(cfg.SUPABASE_URL).includes("xxxxxxxx") && (cfg.SUPABASE_ANON_KEY || "").length > 30;

const $app = document.getElementById("app");
const $nav = document.getElementById("nav");
const $bar = document.getElementById("bar");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const money = (n) => Number(n || 0).toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " ฿";
const fmtDate = (d) => (d ? new Date(d).toLocaleString("th-TH", { dateStyle: "medium", timeStyle: "short" }) : "—");
const safeUrl = (u) => (/^https?:\/\//i.test(u || "") ? u : "");
const pad = (n) => String(n).padStart(2, "0");
const go = (h) => { if (location.hash === h) route(); else location.hash = h; };
const $ = (sel) => $app.querySelector(sel);
const $$ = (sel) => $app.querySelectorAll(sel);
const one = (x) => (Array.isArray(x) ? x[0] : x) || {};

// ---------- แสดงผลแบบลื่น ----------
let routing = 0;
const STALE = Symbol("stale");
function paint(T, html) {
  if (T !== routing) throw STALE;          // ผู้ใช้กดไปหน้าอื่นแล้ว ไม่ต้องวาดทับ
  $app.innerHTML = html;
  $app.classList.remove("enter"); void $app.offsetWidth; $app.classList.add("enter");
  $app.querySelectorAll("img").forEach((img) => {
    if (img.complete && img.naturalWidth) img.classList.add("in");
    else img.addEventListener("load", () => img.classList.add("in"), { once: true });
  });
}
function skeleton(h) {
  if (/^#?\/?$/.test(h)) return `<section class="hero"><div class="sk sk-h"></div><div class="sk sk-p"></div></section>
    <div class="grid">${Array.from({ length: 6 }, () => `<div class="card"><div class="thumb sk"></div><div class="cbody"><div class="sk sk-t"></div></div></div>`).join("")}</div>`;
  return `<div class="sk sk-h" style="width:40%"></div>${Array.from({ length: 4 }, () => `<div class="sk sk-row"></div>`).join("")}`;
}

function toast(msg, type = "ok") {
  const el = document.createElement("div");
  el.className = "flash " + type;
  el.textContent = msg;
  document.getElementById("toast").appendChild(el);
  setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 300); }, 4200);
}
const TH_ERR = {
  "Invalid login credentials": "อีเมลหรือรหัสผ่านไม่ถูกต้อง",
  "Email not confirmed": "ยังไม่ได้ยืนยันอีเมล — กรุณากดลิงก์ในอีเมลก่อน",
  "User already registered": "อีเมลนี้สมัครไว้แล้ว",
  "Password should be at least 6 characters.": "รหัสผ่านต้องยาวอย่างน้อย 6 ตัวอักษร",
  banned: "คุณถูกระงับการใช้งาน",
};
const errMsg = (e) => {
  const m = e?.message || String(e);
  if (/rate limit|too many/i.test(m)) return "ลองบ่อยเกินไป กรุณารอสักครู่";
  if (/row-level security|permission denied/i.test(m)) return "ไม่มีสิทธิ์ทำรายการนี้";
  if (/duplicate key/i.test(m)) return "มีรายการนี้อยู่แล้ว";
  return TH_ERR[m] || m;
};
async function busy(btn, fn) {
  if (btn) btn.disabled = true;
  try { await fn(); } catch (e) { if (e !== STALE) { console.error(e); toast(errMsg(e), "err"); } }
  finally { if (btn && btn.isConnected) btn.disabled = false; }
}
const thumb = (url, cls = "") =>
  `<div class="thumb ${cls}">${safeUrl(url) ? `<img src="${esc(url)}" alt="" loading="lazy" decoding="async">` : "<span>NO IMAGE</span>"}</div>`;
const STATUS = { pending: ["รอตรวจสอบ", "wait"], approved: ["อนุมัติแล้ว", "ok"], rejected: ["ไม่อนุมัติ", "err"], revoked: ["ถูกยึดสิทธิ์", "err"] };
const badge = (s) => { const m = STATUS[s] || [s, ""]; return `<span class="badge ${m[1]}">${m[0]}</span>`; };

// ---------- ยังไม่ได้ตั้งค่า ----------
if (!configured) {
  $app.innerHTML = `<div class="box setup">
    <h1>ยังไม่ได้เชื่อม Supabase</h1>
    <p>เปิดไฟล์ <code>config.js</code> ใน GitHub (กดไอคอนดินสอ) แล้วใส่
      <b>Project URL</b> และ <b>anon public key</b> จาก Supabase → Project Settings → API จากนั้นกด Commit</p>
    <p class="muted small">รอ 1–2 นาทีให้ GitHub อัปเดต แล้วรีเฟรชหน้านี้</p></div>`;
  throw new Error("Supabase not configured");
}

const sb = createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
let session = null, profile = null, settings = {}, banned = false;
const cache = { products: null };
const S = (k, d = "") => settings[k] || d;
const isAdmin = () => !!profile?.is_admin;

async function loadProfile() {
  if (!session) { profile = null; return; }
  const { data } = await sb.from("profiles").select("*").eq("id", session.user.id).maybeSingle();
  profile = data;
}
async function loadSettings() {
  const { data } = await sb.from("settings").select("*");
  settings = Object.fromEntries((data || []).map((r) => [r.k, r.v]));
  const name = S("shop_name", "NEXTSHOP");
  document.getElementById("brand").textContent = name;
  document.getElementById("foot").textContent = `© ${new Date().getFullYear()} ${name}`;
  document.title = name;
}
async function checkIn() {
  const { data, error } = await sb.rpc("check_in");
  banned = !error && data === true;
}

async function renderNav() {
  if (banned) { $nav.innerHTML = session ? `<a href="#" id="logout">ออก</a>` : ""; bindLogout(); return; }
  let pending = 0;
  if (isAdmin()) {
    const { count } = await sb.from("orders").select("id", { count: "exact", head: true }).eq("status", "pending");
    pending = count || 0;
  }
  $nav.innerHTML = `
    <a href="#/" data-nav="home">สินค้า</a>
    ${isAdmin() ? `<a class="admin" href="#/admin" data-nav="admin">แอดมิน${pending ? ` <b class="dot">${pending}</b>` : ""}</a>` : ""}
    ${session
      ? `<a href="#/me" data-nav="me">ของฉัน</a><a href="#" id="logout">ออก</a>`
      : `<a href="#/login" data-nav="login">เข้าสู่ระบบ</a><a class="btn sm" href="#/register">สมัครสมาชิก</a>`}`;
  bindLogout(); markNav();
}
function bindLogout() {
  const lo = document.getElementById("logout");
  if (lo) lo.onclick = async (e) => { e.preventDefault(); await sb.auth.signOut(); toast("ออกจากระบบแล้ว"); go("#/"); };
}
function markNav() {
  const h = location.hash || "#/";
  const key = h.startsWith("#/admin") ? "admin" : h.startsWith("#/me") || h.startsWith("#/get") ? "me" : h === "#/login" ? "login" : /^#?\/?$|^#\/p\//.test(h) ? "home" : "";
  $nav.querySelectorAll("[data-nav]").forEach((a) => a.classList.toggle("on", a.dataset.nav === key));
}

function needLogin() {
  if (session) return true;
  toast("กรุณาเข้าสู่ระบบก่อน", "err");
  sessionStorage.setItem("next", location.hash);
  go("#/login");
  return false;
}
function needAdmin() {
  if (isAdmin()) return true;
  go("#/admin/login");
  return false;
}

// ---------- QR พร้อมเพย์ (ขึ้นยอดเงินอัตโนมัติ) ----------
function promptpayPayload(id, amount) {
  const f = (tag, v) => tag + String(v.length).padStart(2, "0") + v;
  const d = String(id || "").replace(/\D/g, "");
  const acc = d.length >= 15 ? f("03", d) : d.length >= 13 ? f("02", d)
    : f("01", ("0000000000000" + d.replace(/^0/, "66")).slice(-13));
  const amt = Number(amount) > 0 ? f("54", Number(amount).toFixed(2)) : "";
  const body = f("00", "01") + f("01", amt ? "12" : "11") + f("29", f("00", "A000000677010111") + acc) +
    f("58", "TH") + f("53", "764") + amt + "6304";
  let crc = 0xffff;
  for (let i = 0; i < body.length; i++) {
    crc ^= body.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return body + crc.toString(16).toUpperCase().padStart(4, "0");
}
function qrSvg(text) {
  if (!window.makeQR) return "";
  const q = window.makeQR(text), n = q.getModuleCount(), m = 4;
  let d = "";
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c + m} ${r + m}h1v1h-1z`;
  return `<svg class="qr qr-svg" viewBox="0 0 ${n + 2 * m} ${n + 2 * m}" shape-rendering="crispEdges" role="img" aria-label="QR พร้อมเพย์"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}
const validPromptpay = (id) => [10, 13, 15].includes(String(id || "").replace(/\D/g, "").length);

// ---------- อัปโหลด ----------
const IMG = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" };
async function uploadImage(bucket, folder, file) {
  const ext = IMG[file.type];
  if (!ext) throw new Error("รองรับเฉพาะรูป JPG / PNG / WEBP / GIF");
  if (file.size > 10 * 1024 * 1024) throw new Error("รูปใหญ่เกิน 10MB");
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await sb.storage.from(bucket).upload(path, file, { contentType: file.type });
  if (error) throw error;
  return path;
}
const publicUrl = (path) => sb.storage.from("media").getPublicUrl(path).data.publicUrl;

// =================================================================
//  หน้าร้าน
// =================================================================
function homeHtml(items) {
  return `
    <section class="hero">
      <div class="eyebrow"><span>DIGITAL STORE</span><span>${pad(items.length)} ITEMS</span></div>
      <h1>${esc(S("shop_name", "NEXTSHOP"))}</h1>
      <p>${esc(S("tagline", "ซื้อง่าย โอนแล้วแนบสลิป แอดมินอนุมัติ รับลิงก์ดาวน์โหลดได้ทันที"))}</p>
    </section>
    <ol class="steps"><li><b>01</b>เลือกสินค้า</li><li><b>02</b>โอนเงิน แนบสลิป</li><li><b>03</b>รับลิงก์ทันทีที่อนุมัติ</li></ol>
    ${items.length ? "" : `<div class="empty">ยังไม่มีสินค้า</div>`}
    <div class="grid">${items.map((p, i) => `
      <a class="card" href="#/p/${p.id}"><i class="idx">${pad(i + 1)}</i>${thumb(p.image_url)}
        <div class="cbody"><h3>${esc(p.title)}</h3><div class="price">${money(p.price)}</div></div></a>`).join("")}
    </div>`;
}
async function pageHome(T) {
  if (cache.products) paint(T, homeHtml(cache.products));     // แสดงของเดิมทันที แล้วค่อยอัปเดต
  const { data, error } = await sb.from("products").select("id,title,price,image_url,description").eq("active", true).order("id", { ascending: false });
  if (error) throw error;
  const changed = JSON.stringify(data) !== JSON.stringify(cache.products);
  cache.products = data;
  if (changed) paint(T, homeHtml(data));
}

async function pageProduct(T, id) {
  let p = cache.products?.find((x) => String(x.id) === String(id));
  if (!p) {
    const { data } = await sb.from("products").select("*").eq("id", id).maybeSingle();
    p = data;
  }
  if (!p) return paint(T, `<div class="empty">ไม่พบสินค้านี้</div>`);
  let mine = null;
  if (session) {
    const { data } = await sb.from("orders").select("id,status").eq("product_id", id).eq("user_id", session.user.id).order("id", { ascending: false });
    mine = (data || []).find((o) => o.status === "approved") || (data || [])[0] || null;
  }
  let action = `<a class="btn full" href="#/checkout/${p.id}">ซื้อเลย — ${money(p.price)}</a>`;
  if (mine?.status === "approved") action = `<a class="btn full" href="#/get/${mine.id}">ซื้อแล้ว — รับลิงก์</a>`;
  else if (mine?.status === "pending") action = `<p class="note">ส่งสลิปแล้ว กำลังรอแอดมินตรวจสอบ — ดูที่ <a href="#/me">หน้าของฉัน</a></p>`;
  else if (mine?.status === "rejected") action += `<p class="note err">คำสั่งซื้อก่อนหน้าไม่ผ่าน ส่งสลิปใหม่ได้</p>`;
  else if (mine?.status === "revoked") action = `<p class="note err">สิทธิ์ของสินค้านี้ถูกยึดคืน กรุณาติดต่อร้าน</p>`;
  paint(T, `<a class="back" href="#/">← สินค้าทั้งหมด</a>
    <div class="detail">${thumb(p.image_url, "big")}
    <div class="info"><div class="eyebrow"><span>ITEM ${pad(p.id)}</span><span>DIGITAL</span></div>
      <h1>${esc(p.title)}</h1><div class="price lg">${money(p.price)}</div>
      <div class="desc">${esc(p.description).replace(/\n/g, "<br>")}</div>${action}
      <p class="muted small fine">ชำระด้วยการโอนเงิน · แนบสลิป · รับลิงก์ในหน้า “ของฉัน”</p></div></div>`);
}

async function pageCheckout(T, id) {
  if (!needLogin()) return;
  const { data: p } = await sb.from("products").select("*").eq("id", id).eq("active", true).maybeSingle();
  if (!p) return go("#/");
  const qr = S("qr_url"), pp = S("promptpay_id");
  const autoQr = validPromptpay(pp) ? qrSvg(promptpayPayload(pp, p.price)) : "";
  paint(T, `<a class="back" href="#/p/${p.id}">← กลับ</a><h1>ชำระเงิน</h1>
  <div class="checkout">
    <div class="box">
      <h3>01 — โอนเงิน</h3>
      <div class="row"><span>สินค้า</span><b>${esc(p.title)}</b></div>
      <div class="row total"><span>ยอดที่ต้องโอน</span><b>${money(p.price)}</b></div><hr>
      ${autoQr ? `<div class="qrbox">${autoQr}<div class="qrcap"><b>PROMPTPAY</b>สแกนแล้วยอด ${money(p.price)} ขึ้นอัตโนมัติ</div></div>`
        : safeUrl(qr) ? `<img class="qr" src="${esc(qr)}" alt="QR พร้อมเพย์">` : ""}
      <div class="bank">${esc(S("bank_info", autoQr ? "" : "ยังไม่ได้ตั้งค่าบัญชีรับเงิน")).replace(/\n/g, "<br>")}</div>
    </div>
    <form class="box" id="f">
      <h3>02 — แนบสลิป</h3>
      <label class="drop"><input type="file" name="slip" accept="image/*" required>
        <img id="pv" hidden alt=""><span id="pt">แตะเพื่อเลือกรูปสลิป</span></label>
      <label>หมายเหตุ (ถ้ามี)<textarea name="note" rows="2" placeholder="เช่น เวลาโอน / ชื่อบัญชีผู้โอน"></textarea></label>
      <button class="btn full">ส่งสลิป</button>
    </form>
  </div>`);
  const f = $("#f");
  f.slip.onchange = () => {
    const file = f.slip.files[0]; if (!file) return;
    const pv = $("#pv"); pv.src = URL.createObjectURL(file); pv.hidden = false; pv.onload = () => pv.classList.add("in");
    $("#pt").textContent = file.name;
  };
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector("button"), async () => {
      const file = f.slip.files[0];
      if (!file) throw new Error("กรุณาแนบรูปสลิป");
      const slip_path = await uploadImage("slips", session.user.id, file);
      const { error } = await sb.from("orders").insert({ product_id: p.id, slip_path, note: f.note.value.trim() });
      if (error) throw error;
      toast("ส่งสลิปเรียบร้อย! รอแอดมินตรวจสอบ");
      go("#/me");
    });
  };
}

async function pageMe(T) {
  if (!needLogin()) return;
  const { data: orders, error } = await sb.from("orders").select("*, products(title,image_url)")
    .eq("user_id", session.user.id).order("id", { ascending: false });
  if (error) throw error;
  paint(T, `<div class="eyebrow"><span>ACCOUNT</span><span>${esc(profile?.email || session.user.email)}</span></div>
    <h1>สินค้าของฉัน</h1>
    <p class="muted">เมื่อแอดมินอนุมัติแล้ว กด “รับลิงก์” ได้เลย</p>
    ${orders.length ? "" : `<div class="empty">ยังไม่มีคำสั่งซื้อ <a href="#/">ไปเลือกสินค้า</a></div>`}
    <div class="list">${orders.map((o) => `
      <div class="item">${thumb(o.products?.image_url, "sm")}
        <div class="grow"><b>${esc(o.products?.title)}</b>
          <div class="muted small">#${o.id} · ${money(o.amount)} · ${fmtDate(o.created_at)}</div>
          ${badge(o.status)}
          ${["rejected", "revoked"].includes(o.status) && o.admin_note ? `<div class="small err">เหตุผล: ${esc(o.admin_note)}</div>` : ""}
        </div>
        <div>${o.status === "approved" ? `<a class="btn" href="#/get/${o.id}">รับลิงก์</a>`
          : o.status === "rejected" ? `<a class="btn ghost" href="#/checkout/${o.product_id}">ส่งสลิปใหม่</a>` : ""}</div>
      </div>`).join("")}</div>`);
}

async function pageGet(T, orderId) {
  if (!needLogin()) return;
  const { data: o } = await sb.from("orders").select("*, products(title)").eq("id", orderId).maybeSingle();
  if (!o || o.status !== "approved") {
    return paint(T, `<div class="empty">${o?.status === "revoked" ? "สิทธิ์ของคำสั่งซื้อนี้ถูกยึดคืนแล้ว" : "คำสั่งซื้อนี้ยังไม่ได้รับการอนุมัติ หรือไม่ใช่ของคุณ"}</div>`);
  }
  // ฐานข้อมูลจะส่งลิงก์ให้เฉพาะคนที่ได้รับอนุมัติแล้วเท่านั้น
  const { data: sec } = await sb.from("product_secrets").select("*").eq("product_id", o.product_id).maybeSingle();
  const link = safeUrl(sec?.link);
  paint(T, `<div class="box center">
    <div class="big-ok">APPROVED</div><h1>${esc(o.products?.title)}</h1>
    <p class="muted">คำสั่งซื้อ #${o.id} ได้รับการอนุมัติแล้ว</p>
    ${link ? `<a class="btn full" href="${esc(link)}" target="_blank" rel="noopener noreferrer">เปิดลิงก์ดาวน์โหลด</a>
      <div class="linkbox"><input readonly value="${esc(link)}"><button type="button" id="cp">คัดลอก</button></div>` : ""}
    ${sec?.file_path ? `<button class="btn full ghost" id="dl">ดาวน์โหลดไฟล์ (${esc(sec.file_name || "ไฟล์")})</button>` : ""}
    ${!link && !sec?.file_path ? `<p>แอดมินยังไม่ได้ใส่ลิงก์ให้สินค้านี้ กรุณาติดต่อร้าน</p>` : ""}
  </div>`);
  const cp = $("#cp");
  if (cp) cp.onclick = () => { navigator.clipboard.writeText(link); cp.textContent = "คัดลอกแล้ว"; };
  const dl = $("#dl");
  if (dl) dl.onclick = () => busy(dl, async () => {
    const { data, error } = await sb.storage.from("files").createSignedUrl(sec.file_path, 60, { download: sec.file_name || true });
    if (error) throw error;
    location.href = data.signedUrl;  // ลิงก์ชั่วคราว หมดอายุใน 60 วินาที
  });
}

// ---------- สมาชิก ----------
function authForm(T, { title, admin = false, register = false }) {
  paint(T, `<form class="box auth ${admin ? "admin-login" : ""}" id="f">
    <div class="lock">${admin ? "ADMIN ONLY" : register ? "NEW ACCOUNT" : "WELCOME BACK"}</div>
    <h1>${title}</h1>
    ${admin ? `<p class="muted small center">จัดการสินค้า ลิงก์ รูปภาพ ตรวจสลิป และแบนผู้ใช้</p>` : ""}
    ${register ? `<label>ชื่อ<input name="name" required></label>` : ""}
    <label>อีเมล${admin ? "แอดมิน" : ""}<input type="email" name="email" required autocomplete="email"></label>
    <label>รหัสผ่าน<input type="password" name="password" required minlength="6" autocomplete="${register ? "new-password" : "current-password"}"></label>
    ${register ? `<label>ยืนยันรหัสผ่าน<input type="password" name="password2" required minlength="6"></label>` : ""}
    <button class="btn full">${title}</button>
    <p class="muted center small">${admin ? `<a href="#/">← กลับหน้าร้าน</a>`
      : register ? `มีบัญชีแล้ว? <a href="#/login">เข้าสู่ระบบ</a>` : `ยังไม่มีบัญชี? <a href="#/register">สมัครสมาชิก</a>`}</p>
  </form>`);
  return $("#f");
}

function pageLogin(T) {
  if (session) return go("#/");
  const f = authForm(T, { title: "เข้าสู่ระบบ" });
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector("button"), async () => {
      const { error } = await sb.auth.signInWithPassword({ email: f.email.value.trim(), password: f.password.value });
      if (error) throw error;
      session = (await sb.auth.getSession()).data.session;
      await Promise.all([loadProfile(), checkIn()]);
      if (banned) return showBanned();
      toast("เข้าสู่ระบบแล้ว");
      const next = sessionStorage.getItem("next"); sessionStorage.removeItem("next");
      go(next && next.startsWith("#/") ? next : "#/");
    });
  };
}

function pageRegister(T) {
  if (session) return go("#/");
  const f = authForm(T, { title: "สมัครสมาชิก", register: true });
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector("button"), async () => {
      if (f.password.value !== f.password2.value) throw new Error("รหัสผ่านทั้งสองช่องไม่ตรงกัน");
      const email = f.email.value.trim();
      const { data, error } = await sb.auth.signUp({
        email, password: f.password.value,
        options: { data: { name: f.name.value.trim() }, emailRedirectTo: location.origin + location.pathname },
      });
      if (error) throw error;
      if (!data.session) {
        paint(routing, `<div class="box center"><div class="big-ok">CHECK EMAIL</div><h1>เช็กอีเมลของคุณ</h1>
          <p>เราส่งลิงก์ยืนยันไปที่ <b>${esc(email)}</b> กดลิงก์แล้วกลับมาเข้าสู่ระบบได้เลย</p></div>`);
      } else { toast("สมัครสมาชิกสำเร็จ ยินดีต้อนรับ!"); go("#/"); }
    });
  };
}

function showBanned() {
  banned = true; renderNav();
  $app.innerHTML = `<div class="box center banned"><div class="big-ok">ACCESS DENIED</div>
    <h1>คุณถูกระงับการใช้งาน</h1><p class="muted">หากคิดว่าเป็นความผิดพลาด กรุณาติดต่อร้าน</p></div>`;
}

// =================================================================
//  แอดมิน
// =================================================================
function adminBar(on) {
  const t = [["#/admin", "คำสั่งซื้อ / สลิป", "orders"], ["#/admin/products", "สินค้า", "products"],
    ["#/admin/members", "สมาชิก / แบน", "members"], ["#/admin/settings", "ตั้งค่าร้าน", "settings"]];
  return `<div class="adminbar">${t.map(([h, l, k]) => `<a class="${on === k ? "on" : ""}" href="${h}">${l}</a>`).join("")}
    <a href="#" id="alo">ออกจากระบบแอดมิน</a></div>`;
}
function bindAdminBar() {
  $("#alo").onclick = async (e) => { e.preventDefault(); await sb.auth.signOut(); go("#/admin/login"); };
}
async function addBan(kind, value, reason) {
  const { error } = await sb.from("bans").insert({ kind, value, reason: reason || null });
  if (error && !/duplicate key/i.test(error.message)) throw error;
}

function pageAdminLogin(T) {
  if (isAdmin()) return go("#/admin");
  const f = authForm(T, { title: "เข้าสู่ระบบแอดมิน", admin: true });
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector("button"), async () => {
      const { error } = await sb.auth.signInWithPassword({ email: f.email.value.trim(), password: f.password.value });
      if (error) throw error;
      session = (await sb.auth.getSession()).data.session;
      await loadProfile();
      if (!isAdmin()) { await sb.auth.signOut(); throw new Error("บัญชีนี้ไม่ใช่แอดมิน"); }
      await renderNav();
      go("#/admin");
    });
  };
}

async function pageAdminOrders(T, tab = "pending") {
  if (!needAdmin()) return;
  const [{ data: all }, { data: bans }] = await Promise.all([
    sb.from("orders").select("status,amount"), sb.from("bans").select("kind,value")]);
  const cnt = { pending: 0, approved: 0, rejected: 0, revoked: 0 }; let revenue = 0;
  (all || []).forEach((o) => { cnt[o.status]++; if (o.status === "approved") revenue += Number(o.amount); });
  const bannedIp = new Set((bans || []).filter((b) => b.kind === "ip").map((b) => b.value));
  const bannedUser = new Set((bans || []).filter((b) => b.kind === "user").map((b) => b.value));
  let q = sb.from("orders").select("*, products(title), profiles(name,email)").order("id", { ascending: false }).limit(200);
  if (tab !== "all") q = q.eq("status", tab);
  const { data: orders, error } = await q;
  if (error) throw error;
  const urls = {};
  if (orders.length) {
    const { data } = await sb.storage.from("slips").createSignedUrls(orders.map((o) => o.slip_path), 3600);
    (data || []).forEach((d) => { if (d.signedUrl) urls[d.path] = d.signedUrl; });
  }
  const tabs = { pending: "รอตรวจ", approved: "อนุมัติแล้ว", rejected: "ไม่อนุมัติ", revoked: "ยึดสิทธิ์แล้ว", all: "ทั้งหมด" };
  paint(T, `${adminBar("orders")}
    <div class="stats"><div><b>${cnt.pending}</b><span>รอตรวจ</span></div>
      <div><b>${cnt.approved}</b><span>อนุมัติแล้ว</span></div><div><b>${money(revenue)}</b><span>ยอดขาย</span></div></div>
    <div class="tabs">${Object.entries(tabs).map(([k, t]) =>
      `<a class="${tab === k ? "on" : ""}" href="#/admin/o/${k}">${t}${cnt[k] != null ? ` (${cnt[k]})` : ""}</a>`).join("")}</div>
    ${orders.length ? "" : `<div class="empty">ไม่มีรายการ</div>`}
    <div class="slips">${orders.map((o) => {
      const ub = bannedUser.has(o.user_id), ib = o.ip && bannedIp.has(o.ip);
      return `
      <div class="slipcard">
        <a class="slipimg" href="${esc(urls[o.slip_path] || "#")}" target="_blank" rel="noopener"><img loading="lazy" src="${esc(urls[o.slip_path] || "")}" alt="สลิป #${o.id}"></a>
        <div class="slipinfo">
          <div class="row"><b>#${o.id} ${esc(o.products?.title)}</b>${badge(o.status)}</div>
          <dl class="meta">
            <dt>ผู้ซื้อ</dt><dd>${esc(o.profiles?.name) || "—"} ${ub ? `<span class="badge ban">แบนแล้ว</span>` : ""}</dd>
            <dt>อีเมล</dt><dd>${esc(o.profiles?.email)}</dd>
            <dt>ยอด</dt><dd><b>${money(o.amount)}</b></dd>
            <dt>เวลา</dt><dd>${fmtDate(o.created_at)}</dd>
            <dt>IP</dt><dd class="mono">${esc(o.ip || "—")} ${ib ? `<span class="badge ban">แบนแล้ว</span>` : ""}</dd>
            ${o.note ? `<dt>หมายเหตุ</dt><dd>${esc(o.note)}</dd>` : ""}
            ${o.admin_note ? `<dt>เหตุผล</dt><dd>${esc(o.admin_note)}</dd>` : ""}
          </dl>
          <div class="acts" data-id="${o.id}">
            ${o.status === "pending" || o.status === "rejected" ? `<button class="btn ok" data-act="approved">อนุมัติ</button>` : ""}
            ${o.status === "pending" ? `<input placeholder="เหตุผล (ถ้าไม่อนุมัติ)"><button class="btn danger" data-act="rejected">ไม่อนุมัติ</button>` : ""}
            ${o.status === "approved" ? `<input placeholder="เหตุผลที่ยึดคืน"><button class="btn danger" data-act="revoked">ยึดสิทธิ์คืน</button>` : ""}
            ${o.status === "revoked" ? `<button class="btn ok" data-act="approved">คืนสิทธิ์</button>` : ""}
            ${o.status === "rejected" ? `<button class="btn ghost" data-act="pending">ย้ายกลับไปรอตรวจ</button>` : ""}
          </div>
          <div class="acts sub">
            ${ub ? "" : `<button class="btn ghost sm" data-ban="user" data-v="${esc(o.user_id)}">แบนบัญชีนี้</button>`}
            ${o.ip && !ib ? `<button class="btn ghost sm" data-ban="ip" data-v="${esc(o.ip)}">แบน IP นี้</button>` : ""}
          </div>
        </div>
      </div>`; }).join("")}</div>`);
  bindAdminBar();
  $$("[data-act]").forEach((b) => b.onclick = () => {
    const box = b.closest(".acts"); const act = b.dataset.act;
    if (act === "rejected" && !confirm("ไม่อนุมัติรายการนี้?")) return;
    if (act === "revoked" && !confirm("ยึดสิทธิ์คืน? ผู้ซื้อจะเปิดลิงก์/ไฟล์ของสินค้านี้ไม่ได้อีก")) return;
    busy(b, async () => {
      const { error } = await sb.from("orders").update({ status: act, admin_note: box.querySelector("input")?.value.trim() || null }).eq("id", box.dataset.id);
      if (error) throw error;
      toast({ approved: `อนุมัติ #${box.dataset.id} แล้ว — ผู้ซื้อกดรับลิงก์ได้ทันที`, revoked: `ยึดสิทธิ์ #${box.dataset.id} คืนแล้ว` }[act] || "อัปเดตแล้ว");
      await renderNav(); pageAdminOrders(routing, tab);
    });
  });
  bindBanButtons(() => pageAdminOrders(routing, tab));
}

function bindBanButtons(refresh) {
  $$("[data-ban]").forEach((b) => b.onclick = () => {
    const kind = b.dataset.ban, v = b.dataset.v;
    const reason = prompt(kind === "ip" ? `แบน IP ${v}?\nใส่เหตุผล (ไม่บังคับ):` : "แบนบัญชีนี้?\nใส่เหตุผล (ไม่บังคับ):");
    if (reason === null) return;
    busy(b, async () => { await addBan(kind, v, reason.trim()); toast(kind === "ip" ? `แบน IP ${v} แล้ว` : "แบนบัญชีแล้ว"); refresh(); });
  });
  $$("[data-unban]").forEach((b) => b.onclick = () => {
    if (!confirm("ปลดแบน?")) return;
    busy(b, async () => {
      const { error } = await sb.from("bans").delete().eq("kind", b.dataset.unban).eq("value", b.dataset.v);
      if (error) throw error;
      toast("ปลดแบนแล้ว"); refresh();
    });
  });
}

async function pageAdminMembers(T) {
  if (!needAdmin()) return;
  const [{ data: users, error }, { data: bans }] = await Promise.all([
    sb.from("profiles").select("id,name,email,is_admin,last_ip,last_seen,created_at, orders(count)").order("created_at", { ascending: false }).limit(500),
    sb.from("bans").select("*").order("id", { ascending: false })]);
  if (error) throw error;
  const bIp = new Set(bans.filter((b) => b.kind === "ip").map((b) => b.value));
  const bUser = new Set(bans.filter((b) => b.kind === "user").map((b) => b.value));
  const nameOf = Object.fromEntries(users.map((u) => [u.id, u.email]));
  paint(T, `${adminBar("members")}
    <div class="stats"><div><b>${users.length}</b><span>สมาชิก</span></div>
      <div><b>${bUser.size}</b><span>บัญชีที่แบน</span></div><div><b>${bIp.size}</b><span>IP ที่แบน</span></div></div>
    <input class="search" id="q" placeholder="ค้นหาชื่อ / อีเมล / IP">
    <div class="list" id="ul">${users.map((u) => {
      const ub = bUser.has(u.id), ib = u.last_ip && bIp.has(u.last_ip);
      return `<div class="item" data-s="${esc((u.name + " " + u.email + " " + (u.last_ip || "")).toLowerCase())}">
        <div class="grow"><b>${esc(u.name) || "—"}</b> ${u.is_admin ? `<span class="badge ok">ADMIN</span>` : ""} ${ub ? `<span class="badge ban">แบนบัญชี</span>` : ""}
          <div class="muted small">${esc(u.email)} · ซื้อ ${one(u.orders).count ?? 0} ครั้ง</div>
          <div class="muted small">IP ล่าสุด ${esc(u.last_ip || "—")} ${ib ? `<span class="badge ban">IP แบน</span>` : ""} · เข้าล่าสุด ${fmtDate(u.last_seen)}</div></div>
        ${u.is_admin ? "" : `<div class="acts">
          ${ub ? `<button class="btn ghost sm" data-unban="user" data-v="${esc(u.id)}">ปลดแบนบัญชี</button>` : `<button class="btn danger sm" data-ban="user" data-v="${esc(u.id)}">แบนบัญชี</button>`}
          ${u.last_ip ? ib ? `<button class="btn ghost sm" data-unban="ip" data-v="${esc(u.last_ip)}">ปลดแบน IP</button>` : `<button class="btn danger sm" data-ban="ip" data-v="${esc(u.last_ip)}">แบน IP</button>` : ""}
        </div>`}
      </div>`; }).join("")}</div>

    <h2 class="sec">รายการที่แบน</h2>
    <form class="acts addban" id="bf"><input name="ip" placeholder="แบน IP เอง เช่น 203.0.113.5" required pattern="[0-9a-fA-F:.]{3,45}">
      <input name="reason" placeholder="เหตุผล (ไม่บังคับ)"><button class="btn">แบน IP</button></form>
    ${bans.length ? "" : `<div class="empty">ยังไม่มีใครถูกแบน</div>`}
    <div class="list">${bans.map((b) => `<div class="item"><div class="grow">
        <span class="badge">${b.kind === "ip" ? "IP" : "บัญชี"}</span> <b class="mono">${esc(b.kind === "ip" ? b.value : nameOf[b.value] || b.value)}</b>
        <div class="muted small">${esc(b.reason || "ไม่ระบุเหตุผล")} · ${fmtDate(b.created_at)}</div></div>
        <button class="btn ghost sm" data-unban="${b.kind}" data-v="${esc(b.value)}">ปลดแบน</button></div>`).join("")}</div>`);
  bindAdminBar();
  const refresh = () => pageAdminMembers(routing);
  bindBanButtons(refresh);
  $("#q").oninput = (e) => {
    const s = e.target.value.trim().toLowerCase();
    $$("#ul .item").forEach((el) => { el.hidden = s && !el.dataset.s.includes(s); });
  };
  const bf = $("#bf");
  bf.onsubmit = (e) => {
    e.preventDefault();
    busy(bf.querySelector("button"), async () => { await addBan("ip", bf.ip.value.trim(), bf.reason.value.trim()); toast("แบน IP แล้ว"); refresh(); });
  };
}

async function pageAdminProducts(T, editId) {
  if (!needAdmin()) return;
  const { data: items, error } = await sb.from("products").select("*, product_secrets(link,file_path,file_name)").order("id", { ascending: false });
  if (error) throw error;
  const p = items.find((x) => String(x.id) === String(editId)) || { id: 0, title: "", description: "", price: "", active: true };
  const sec = one(p.product_secrets);
  paint(T, `${adminBar("products")}
  <form class="box" id="f">
    <h2>${p.id ? "แก้ไขสินค้า #" + p.id : "เพิ่มสินค้าใหม่"}</h2>
    <div class="two">
      <label>ชื่อสินค้า<input name="title" required value="${esc(p.title)}"></label>
      <label>ราคา (บาท)<input type="number" step="0.01" min="0" name="price" required value="${esc(p.price)}"></label>
    </div>
    <label>รายละเอียด<textarea name="description" rows="4">${esc(p.description)}</textarea></label>
    <label>ลิงก์ลับที่จะให้ผู้ซื้อ (ไปที่ไหนก็ได้ — คนจะเห็นก็ต่อเมื่อได้รับอนุมัติแล้วเท่านั้น)
      <input name="link" placeholder="https://..." value="${esc(sec.link)}"></label>
    <div class="two">
      <label>รูปสินค้า ${p.image_url ? "(มีแล้ว — เลือกใหม่เพื่อเปลี่ยน)" : ""}<input type="file" name="image" accept="image/*"></label>
      <label>หรือ อัปโหลดไฟล์ให้ดาวน์โหลด (ไม่เกิน 50MB) ${sec.file_name ? `<br><small>ปัจจุบัน: ${esc(sec.file_name)}</small>` : ""}
        <input type="file" name="file"></label>
    </div>
    ${sec.file_path ? `<label class="check"><input type="checkbox" name="remove_file"> ลบไฟล์ที่อัปโหลดไว้</label>` : ""}
    <label class="check"><input type="checkbox" name="active" ${p.active ? "checked" : ""}> แสดงสินค้าบนหน้าร้าน</label>
    <div class="acts"><button class="btn">บันทึก</button>${p.id ? `<a class="btn ghost" href="#/admin/products">ยกเลิก</a>` : ""}</div>
  </form>
  <h2 class="sec">สินค้าทั้งหมด</h2>
  <div class="list">${items.map((it) => { const s = one(it.product_secrets); return `
    <div class="item">${thumb(it.image_url, "sm")}
      <div class="grow"><b>${esc(it.title)}</b> ${it.active ? "" : `<span class="badge">ซ่อนอยู่</span>`}
        <div class="muted small">${money(it.price)} ${s.link ? "· LINK" : ""} ${s.file_path ? "· FILE" : ""}</div></div>
      <div class="acts"><a class="btn ghost sm" href="#/admin/products/${it.id}">แก้ไข</a>
        <button class="btn danger sm" data-del="${it.id}">ลบ</button></div>
    </div>`; }).join("")}</div>`);
  bindAdminBar();

  const f = $("#f");
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector("button"), async () => {
      const link = f.link.value.trim();
      if (link && !safeUrl(link)) throw new Error("ลิงก์ต้องขึ้นต้นด้วย http:// หรือ https://");
      const row = { title: f.title.value.trim(), description: f.description.value.trim(),
        price: Math.max(0, Number(f.price.value) || 0), active: f.active.checked };
      if (f.image.files[0]) row.image_url = publicUrl(await uploadImage("media", "products", f.image.files[0]));
      let id = p.id;
      if (id) { const { error } = await sb.from("products").update(row).eq("id", id); if (error) throw error; }
      else { const { data, error } = await sb.from("products").insert(row).select("id").single(); if (error) throw error; id = data.id; }

      const secret = { product_id: id, link: link || null, file_path: sec.file_path || null, file_name: sec.file_name || null };
      const file = f.file.files[0];
      if (file || f.remove_file?.checked) {
        if (sec.file_path) await sb.storage.from("files").remove([sec.file_path]);
        secret.file_path = null; secret.file_name = null;
      }
      if (file) {
        if (file.size > 50 * 1024 * 1024) throw new Error("ไฟล์ใหญ่เกิน 50MB — แนะนำอัปไว้ที่ Google Drive แล้วใส่เป็นลิงก์แทน");
        const ext = (file.name.match(/\.([a-z0-9]{1,8})$/i) || [, "bin"])[1].toLowerCase();
        const path = `${id}/${crypto.randomUUID()}.${ext}`;
        const { error } = await sb.storage.from("files").upload(path, file, { contentType: "application/octet-stream" });
        if (error) throw error;
        secret.file_path = path; secret.file_name = file.name;
      }
      const { error } = await sb.from("product_secrets").upsert(secret);
      if (error) throw error;
      cache.products = null;
      toast(p.id ? "บันทึกการแก้ไขแล้ว" : "เพิ่มสินค้าแล้ว");
      go("#/admin/products");
    });
  };
  $$("[data-del]").forEach((b) => b.onclick = () => {
    if (!confirm("ลบสินค้านี้?")) return;
    busy(b, async () => {
      const id = b.dataset.del;
      const { count } = await sb.from("orders").select("id", { count: "exact", head: true }).eq("product_id", id);
      if (count > 0) {
        await sb.from("products").update({ active: false }).eq("id", id);
        toast("สินค้านี้มีคนซื้อแล้ว จึงซ่อนไว้แทนการลบ (คนที่ซื้อแล้วยังรับลิงก์ได้)");
      } else {
        const s = one(items.find((x) => String(x.id) === id)?.product_secrets);
        if (s.file_path) await sb.storage.from("files").remove([s.file_path]);
        const { error } = await sb.from("products").delete().eq("id", id);
        if (error) throw error;
        toast("ลบสินค้าแล้ว");
      }
      cache.products = null;
      pageAdminProducts(routing);
    });
  });
}

async function pageAdminSettings(T) {
  if (!needAdmin()) return;
  await loadSettings();
  const qr = S("qr_url");
  paint(T, `${adminBar("settings")}
  <form class="box" id="f"><h2>ตั้งค่าร้าน</h2>
    <label>ชื่อร้าน<input name="shop_name" value="${esc(S("shop_name", "NEXTSHOP"))}"></label>
    <label>คำโปรยหน้าแรก<input name="tagline" value="${esc(S("tagline"))}"></label>
    <label>ข้อมูลบัญชีรับเงิน (แสดงในหน้าชำระเงิน)
      <textarea name="bank_info" rows="4" placeholder="ธนาคาร...&#10;เลขบัญชี ...&#10;ชื่อบัญชี ...&#10;พร้อมเพย์ ...">${esc(S("bank_info"))}</textarea></label>
    <label>เบอร์พร้อมเพย์ / เลขบัตรประชาชน (แนะนำ — เว็บจะสร้าง QR พร้อมยอดเงินให้อัตโนมัติ)
      <input name="promptpay_id" inputmode="numeric" placeholder="0812345678" value="${esc(S("promptpay_id"))}"></label>
    ${validPromptpay(S("promptpay_id")) ? `<div class="qrbox sm">${qrSvg(promptpayPayload(S("promptpay_id"), 1))}<div class="qrcap"><b>ตัวอย่าง</b>QR ยอด 1.00 ฿ — ลองสแกนด้วยแอปธนาคารเพื่อเช็กชื่อบัญชี (ไม่ต้องโอน)</div></div>` : ""}
    <label>หรือ รูป QR ของคุณเอง (ใช้เมื่อไม่ได้ใส่เบอร์พร้อมเพย์)<input type="file" name="qr" accept="image/*"></label>
    ${safeUrl(qr) ? `<img class="qr" src="${esc(qr)}" alt=""><label class="check"><input type="checkbox" name="remove_qr"> ลบรูป QR</label>` : ""}
    <button class="btn">บันทึก</button></form>`);
  bindAdminBar();
  const f = $("#f");
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector("button"), async () => {
      const pp = f.promptpay_id.value.replace(/\D/g, "");
      if (pp && !validPromptpay(pp)) throw new Error("เบอร์พร้อมเพย์ต้องเป็นเบอร์มือถือ 10 หลัก หรือเลขบัตร 13 หลัก");
      const rows = [["shop_name", f.shop_name.value.trim()], ["tagline", f.tagline.value.trim()], ["bank_info", f.bank_info.value.trim()], ["promptpay_id", pp]];
      if (f.qr.files[0]) rows.push(["qr_url", publicUrl(await uploadImage("media", "settings", f.qr.files[0]))]);
      else if (f.remove_qr?.checked) rows.push(["qr_url", ""]);
      const { error } = await sb.from("settings").upsert(rows.map(([k, v]) => ({ k, v })));
      if (error) throw error;
      toast("บันทึกการตั้งค่าแล้ว");
      pageAdminSettings(routing);
    });
  };
}

// =================================================================
//  เส้นทาง (ใช้ # เพื่อให้ทำงานบน GitHub Pages ได้)
// =================================================================
const routes = [
  [/^#?\/?$/, pageHome],
  [/^#\/p\/(\d+)$/, pageProduct],
  [/^#\/checkout\/(\d+)$/, pageCheckout],
  [/^#\/me$/, pageMe],
  [/^#\/get\/(\d+)$/, pageGet],
  [/^#\/login$/, pageLogin],
  [/^#\/register$/, pageRegister],
  [/^#\/admin\/login$/, pageAdminLogin],
  [/^#\/admin$/, (T) => pageAdminOrders(T, "pending")],
  [/^#\/admin\/o\/(pending|approved|rejected|revoked|all)$/, pageAdminOrders],
  [/^#\/admin\/products$/, (T) => pageAdminProducts(T)],
  [/^#\/admin\/products\/(\d+)$/, pageAdminProducts],
  [/^#\/admin\/members$/, pageAdminMembers],
  [/^#\/admin\/settings$/, pageAdminSettings],
];
async function route() {
  const T = ++routing;
  const h = location.hash || "#/";
  if (/access_token|error_description/.test(h)) return;  // กำลังยืนยันอีเมล
  markNav();
  const isAdminPage = h.startsWith("#/admin");
  if (banned && !isAdminPage) return showBanned();
  for (const [re, fn] of routes) {
    const m = h.match(re);
    if (!m) continue;
    $bar.className = "go";
    const sk = setTimeout(() => { if (T === routing) $app.innerHTML = skeleton(h); }, 160);
    window.scrollTo({ top: 0 });
    try { await fn(T, ...m.slice(1)); } catch (e) {
      if (e !== STALE) {
        console.error(e);
        if (T === routing) $app.innerHTML = `<div class="empty">เกิดข้อผิดพลาด: ${esc(errMsg(e))}</div>`;
      }
    } finally {
      clearTimeout(sk);
      if (T === routing) { $bar.className = "done"; setTimeout(() => { if (T === routing) $bar.className = ""; }, 400); }
    }
    return;
  }
  go("#/");
}

window.addEventListener("hashchange", route);
sb.auth.onAuthStateChange(async (event, s) => {
  if (event === "INITIAL_SESSION") return;
  session = s;
  setTimeout(async () => {               // ห้ามเรียก supabase ตรงๆ ใน callback นี้
    await loadProfile(); await checkIn(); await renderNav();
    if (event === "SIGNED_IN" && /access_token/.test(location.hash)) { toast("ยืนยันอีเมลเรียบร้อย"); go("#/"); }
  }, 0);
});

(async () => {
  session = (await sb.auth.getSession()).data.session;
  if (/access_token/.test(location.hash)) { if (session) toast("ยืนยันอีเมลเรียบร้อย"); history.replaceState(null, "", location.pathname + "#/"); }
  await Promise.all([loadProfile(), loadSettings(), checkIn()]);
  await renderNav();
  route();
})();
