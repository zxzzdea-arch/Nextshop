// NEXTSHOP — ลูกเล่น / เอฟเฟกต์ (แยกจากระบบร้าน ปิดได้โดยลบไฟล์นี้)
(function () {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const touch = matchMedia("(hover: none)").matches;
  const fx = (window.fx = {});

  // ---------- 1. ฝุ่นพิกเซลลอยบนพื้นหลัง ----------
  const bg = document.createElement("canvas");
  bg.id = "pixfield";
  document.body.prepend(bg);
  const g = bg.getContext("2d");
  let W, H, dots = [];
  function resize() {
    W = bg.width = innerWidth; H = bg.height = innerHeight;
    const n = Math.min(touch ? 26 : 60, Math.floor((W * H) / 26000));
    dots = Array.from({ length: n }, () => newDot(true));
  }
  function newDot(anyY) {
    const s = [2, 2, 3, 4][Math.floor(Math.random() * 4)];
    return { x: Math.random() * W, y: anyY ? Math.random() * H : H + 10, s, v: 0.15 + Math.random() * 0.45, a: 0.08 + Math.random() * 0.3, t: Math.random() * 6 };
  }
  let mx = -999, my = -999;
  addEventListener("pointermove", (e) => { mx = e.clientX; my = e.clientY; }, { passive: true });
  function tick() {
    g.clearRect(0, 0, W, H);
    for (const d of dots) {
      d.y -= d.v; d.t += 0.02;
      const dx = d.x - mx, dy = d.y - my, dist = dx * dx + dy * dy;
      if (dist < 9000) { d.x += dx / 60; d.y += dy / 60; }          // หลบเมาส์
      if (d.y < -10) Object.assign(d, newDot(false));
      g.globalAlpha = d.a * (0.6 + 0.4 * Math.sin(d.t));
      g.fillStyle = "#fff";
      g.fillRect(Math.round(d.x), Math.round(d.y), d.s, d.s);
    }
    requestAnimationFrame(tick);
  }
  if (!reduce) { resize(); addEventListener("resize", resize); tick(); }

  // ---------- 2. คลิกแล้วพิกเซลแตก ----------
  const burst = document.createElement("canvas");
  burst.id = "pixburst";
  document.body.appendChild(burst);
  const b = burst.getContext("2d");
  let parts = [], running = false;
  function sizeBurst() { burst.width = innerWidth; burst.height = innerHeight; }
  sizeBurst(); addEventListener("resize", sizeBurst);
  fx.burst = function (x, y, n = 14, spread = 5, colors = ["#fff", "#bbb", "#777"]) {
    if (reduce) return;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, sp = 1 + Math.random() * spread;
      parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 2, s: 3 + Math.floor(Math.random() * 4), life: 1, c: colors[i % colors.length] });
    }
    if (!running) { running = true; requestAnimationFrame(step); }
  };
  function step() {
    b.clearRect(0, 0, burst.width, burst.height);
    parts = parts.filter((p) => p.life > 0);
    for (const p of parts) {
      p.x += p.vx; p.y += p.vy; p.vy += 0.25; p.life -= 0.022;
      b.globalAlpha = Math.max(0, p.life);
      b.fillStyle = p.c;
      b.fillRect(Math.round(p.x / 2) * 2, Math.round(p.y / 2) * 2, p.s, p.s);
    }
    if (parts.length) requestAnimationFrame(step); else { running = false; b.clearRect(0, 0, burst.width, burst.height); }
  }
  addEventListener("pointerdown", (e) => {
    if (e.target.closest(".btn,.card,button,nav a,.adminbar a")) fx.burst(e.clientX, e.clientY);
  });

  // ---------- 3. พลุพิกเซล (ตอนได้รับของ) ----------
  fx.confetti = function () {
    for (let i = 0; i < 5; i++)
      setTimeout(() => fx.burst(innerWidth * (0.15 + Math.random() * 0.7), innerHeight * (0.2 + Math.random() * 0.3), 40, 9, ["#fff", "#ddd", "#999", "#555"]), i * 160);
  };

  // ---------- 4. หัวร้านแบบพิกเซลค่อยๆ ประกอบ + กลิตช์ ----------
  function heroTitle(h1) {
    if (h1.dataset.fx) return;
    h1.dataset.fx = 1;
    const txt = h1.textContent;
    h1.setAttribute("aria-label", txt);
    h1.innerHTML = [...txt].map((c, i) => `<span class="ch" aria-hidden="true" style="--i:${i}">${c === " " ? "&nbsp;" : c.replace(/[<>&]/g, "")}</span>`).join("");
    h1.classList.add("glitch");
    h1.dataset.text = txt;
  }

  // ---------- 5. การ์ดเอียงตามเมาส์ + ประกายพิกเซล ----------
  function tilt(card) {
    if (card.dataset.fx || touch || reduce) return;
    card.dataset.fx = 1;
    card.addEventListener("pointermove", (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5, py = (e.clientY - r.top) / r.height - 0.5;
      card.style.setProperty("--rx", (-py * 8).toFixed(2) + "deg");
      card.style.setProperty("--ry", (px * 10).toFixed(2) + "deg");
      card.style.setProperty("--mx", ((px + 0.5) * 100).toFixed(1) + "%");
      card.style.setProperty("--my", ((py + 0.5) * 100).toFixed(1) + "%");
    });
    card.addEventListener("pointerleave", () => { card.style.setProperty("--rx", "0deg"); card.style.setProperty("--ry", "0deg"); });
  }

  // ---------- 6. ตัวเลขวิ่ง ----------
  function countUp(el) {
    if (el.dataset.fx) return;
    el.dataset.fx = 1;
    const raw = el.textContent.trim();
    const m = raw.match(/^([\d,]+(?:\.\d+)?)(.*)$/);
    if (!m || reduce) return;
    const end = parseFloat(m[1].replace(/,/g, "")), dec = (m[1].split(".")[1] || "").length, suf = m[2];
    const t0 = performance.now(), dur = 700;
    (function f(t) {
      const k = Math.min(1, (t - t0) / dur), v = end * (1 - Math.pow(1 - k, 3));
      el.textContent = v.toLocaleString("th-TH", { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suf;
      if (k < 1) requestAnimationFrame(f); else el.textContent = raw;
    })(t0);
  }

  // ---------- 7. โผล่ขึ้นตอนเลื่อนจอ ----------
  const io = "IntersectionObserver" in window && !reduce
    ? new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { const t = e.target; t.classList.add("shown"); io.unobserve(t); setTimeout(() => t.classList.remove("reveal", "shown"), 1100); } }), { threshold: 0.12 })
    : null;

  // ---------- ผูกกับทุกหน้าที่วาดใหม่ ----------
  function wire(root) {
    root.querySelectorAll(".hero h1").forEach(heroTitle);
    root.querySelectorAll(".card").forEach((c, i) => {
      tilt(c);
      if (io && !c.dataset.rv) { c.dataset.rv = 1; c.classList.add("reveal"); c.style.setProperty("--d", (i % 8) * 60 + "ms"); io.observe(c); }
    });
    root.querySelectorAll(".stats b, .eyebrow .cnt").forEach(countUp);
    const bo = root.querySelector(".big-ok");
    if (bo && !bo.dataset.fx && /APPROVED/.test(bo.textContent)) { bo.dataset.fx = 1; fx.confetti(); }
  }
  const app = document.getElementById("app");
  new MutationObserver(() => wire(app)).observe(app, { childList: true });
  wire(document);
})();
