// ====================================================================
//  ใส่ค่าจาก Supabase ตรงนี้ (Project Settings → API)
//  - Project URL
//  - anon public key  (คีย์นี้เปิดเผยได้ ปลอดภัย เพราะสิทธิ์ถูกล็อกไว้ในฐานข้อมูลแล้ว)
//  ❌ ห้ามใส่ service_role key เด็ดขาด
// ====================================================================
window.SHOP_CONFIG = {
  SUPABASE_URL: "https://xxxxxxxx.supabase.co",
  SUPABASE_ANON_KEY: "ใส่-anon-key-ตรงนี้",
};
